var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__dca7e5e6._.js")
R.c("server/chunks/[root-of-the-server]__de90a38c._.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_1c865db8.js")
R.m(59061)
module.exports=R.m(59061).exports
