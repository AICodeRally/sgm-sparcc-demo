var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/opschief/route.js")
R.c("server/chunks/[root-of-the-server]__3ea8b09c._.js")
R.c("server/chunks/lib_ai_rally-llm-client_ts_04b04801._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1fcccb22.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_opschief_route_actions_64c6cfe1.js")
R.m(61425)
module.exports=R.m(61425).exports
