var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sgm/policies/route.js")
R.c("server/chunks/[root-of-the-server]__0b7576bd._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/lib_2f92e816._.js")
R.c("server/chunks/_next-internal_server_app_api_sgm_policies_route_actions_3a3d0f9a.js")
R.m(24124)
module.exports=R.m(24124).exports
