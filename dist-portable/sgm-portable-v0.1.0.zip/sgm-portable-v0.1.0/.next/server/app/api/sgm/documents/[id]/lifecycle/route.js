var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sgm/documents/[id]/lifecycle/route.js")
R.c("server/chunks/[root-of-the-server]__fa7352f2._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/lib_2f92e816._.js")
R.c("server/chunks/ce889_server_app_api_sgm_documents_[id]_lifecycle_route_actions_8741bbd4.js")
R.m(85558)
module.exports=R.m(85558).exports
