var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sgm/documents/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__9adc8262._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/lib_2f92e816._.js")
R.c("server/chunks/_next-internal_server_app_api_sgm_documents_[id]_route_actions_01d76f2c.js")
R.m(38950)
module.exports=R.m(38950).exports
