var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/henryschein/plans/route.js")
R.c("server/chunks/[root-of-the-server]__924a6aae._.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_henryschein_plans_route_actions_9a9a2b8a.js")
R.m(97945)
module.exports=R.m(97945).exports
