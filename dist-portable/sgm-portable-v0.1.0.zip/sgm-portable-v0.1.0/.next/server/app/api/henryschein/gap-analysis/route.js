var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/henryschein/gap-analysis/route.js")
R.c("server/chunks/[root-of-the-server]__37d87762._.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_henryschein_gap-analysis_route_actions_489138b3.js")
R.m(24624)
module.exports=R.m(24624).exports
