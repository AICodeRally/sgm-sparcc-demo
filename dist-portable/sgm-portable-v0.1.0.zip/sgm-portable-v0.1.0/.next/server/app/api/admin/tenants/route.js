var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/tenants/route.js")
R.c("server/chunks/[root-of-the-server]__812ae02b._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__de90a38c._.js")
R.c("server/chunks/[root-of-the-server]__0e43a126._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_tenants_route_actions_503902f7.js")
R.m(87567)
module.exports=R.m(87567).exports
