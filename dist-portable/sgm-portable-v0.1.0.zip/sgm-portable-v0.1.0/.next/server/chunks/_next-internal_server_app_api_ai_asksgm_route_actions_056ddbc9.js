module.exports=[19889,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_asksgm_route_actions_056ddbc9.js.map