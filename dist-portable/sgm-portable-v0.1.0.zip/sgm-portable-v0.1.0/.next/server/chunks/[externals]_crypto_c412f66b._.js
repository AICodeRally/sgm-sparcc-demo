module.exports=[54799,(r,e,o)=>{e.exports=r.x("crypto",()=>require("crypto"))}];

//# sourceMappingURL=%5Bexternals%5D_crypto_c412f66b._.js.map