module.exports=[70290,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_documents_%5Bid%5D_download_route_actions_5d259d9c.js.map