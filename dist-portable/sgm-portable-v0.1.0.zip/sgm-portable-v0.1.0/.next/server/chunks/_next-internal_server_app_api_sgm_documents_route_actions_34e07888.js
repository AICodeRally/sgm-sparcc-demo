module.exports=[5842,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_documents_route_actions_34e07888.js.map