module.exports=[94048,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_documents_%5Bid%5D_versions_route_actions_248ec100.js.map