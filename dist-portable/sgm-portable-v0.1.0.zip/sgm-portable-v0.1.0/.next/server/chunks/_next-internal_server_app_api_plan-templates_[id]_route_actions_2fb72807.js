module.exports=[37387,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plan-templates_%5Bid%5D_route_actions_2fb72807.js.map