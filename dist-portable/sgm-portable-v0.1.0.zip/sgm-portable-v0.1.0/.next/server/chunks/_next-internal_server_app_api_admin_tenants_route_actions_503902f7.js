module.exports=[46595,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tenants_route_actions_503902f7.js.map