module.exports=[9628,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_sgm_documents_%5Bid%5D_lifecycle_route_actions_8741bbd4.js.map