module.exports=[21361,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_search_route_actions_9969787e.js.map