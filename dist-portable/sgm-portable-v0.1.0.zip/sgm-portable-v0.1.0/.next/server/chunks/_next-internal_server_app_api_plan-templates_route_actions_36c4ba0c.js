module.exports=[66140,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plan-templates_route_actions_36c4ba0c.js.map