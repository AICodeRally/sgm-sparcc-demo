module.exports=[93516,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_diagnostics_route_actions_481a9423.js.map