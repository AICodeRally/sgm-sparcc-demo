module.exports=[62705,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_policies_%5Bid%5D_route_actions_a1233bd0.js.map