module.exports=[65744,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sgm_documents_%5Bid%5D_route_actions_01d76f2c.js.map