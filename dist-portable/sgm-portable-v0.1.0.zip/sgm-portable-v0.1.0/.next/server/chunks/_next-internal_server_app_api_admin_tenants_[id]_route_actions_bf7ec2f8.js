module.exports=[46948,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tenants_%5Bid%5D_route_actions_bf7ec2f8.js.map